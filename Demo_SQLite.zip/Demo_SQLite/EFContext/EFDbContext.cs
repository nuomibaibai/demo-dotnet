﻿namespace EFContext
{
    using Model;
    using System.Data.Entity;
    using System.Data.Entity.ModelConfiguration.Conventions;
    public class EFDbContext : DbContext
    {
        public EFDbContext() : base("name=SQLiteContext")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();//设置移除复数形式
        }

        public DbSet<Batch> Batchs { get; set; }
        public DbSet<Data> Datas { get; set; }
    }
}
