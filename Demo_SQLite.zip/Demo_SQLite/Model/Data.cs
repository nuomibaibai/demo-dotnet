﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Data
    {
        [DisplayName("UID")]
        public Guid UID { get; set; }
        [DisplayName("批次号")]
        public string BatchNo { get; set; }
        [DisplayName("传票番号")]
        public string No1 { get; set; }
        [DisplayName("纳品番号")]
        public string No2 { get; set; }
        [DisplayName("总额")]
        public double Money { get; set; }
        [DisplayName("备用字段1")]
        public string Opt1 { get; set; }
        [DisplayName("备用字段2")]
        public string Opt2 { get; set; }
        [DisplayName("文件名称")]
        public string FileName { get; set; }
        [DisplayName("创建时间")]
        public string CreateDate { get; set; }
        [DisplayName("创建用户")]
        public string CreateUser { get; set; }
    }
}
