﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Batch
    {
        [DisplayName("UID")]
        public Guid UID { get; set; }
        [DisplayName("批次号")]
        public string Batchno { set; get; }
        [DisplayName("总数")]
        public int Total { set; get; }
        [DisplayName("总金额")]
        public double TotalMoney { set; get; }
        [DisplayName("创建时间")]
        public string CreateDate { set; get; }
        [DisplayName("创建用户")]
        public string CreateUser { set; get; }

    }
}
