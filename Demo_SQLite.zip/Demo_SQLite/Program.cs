﻿using EFContext;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_SQLite
{
    class Program
    {
        static void Main(string[] args)
        {
            Batch batch = new Batch()
            {
                Batchno = "test",
                UID = Guid.NewGuid(),
                Total = 0,
                TotalMoney = 0,
                CreateDate = DateTime.Now.ToString("yyyyMMddHHmmss"),
                CreateUser = "hud",
            };
            using (var db = new EFDbContext())
            {
                var Batchs = db.Batchs.ToList();
                db.Batchs.Add(batch);
                var result = db.SaveChanges();
                if (result > 0)
                {
                    Console.WriteLine("同步成功！");
                }
                else
                {
                    Console.WriteLine("同步失败！");
                }
            }
        }
    }
}
