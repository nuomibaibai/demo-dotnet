﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;

namespace CreateZip
{
    class Program
    {
        static void Main(string[] args)
        {

            

        }
    }
}
