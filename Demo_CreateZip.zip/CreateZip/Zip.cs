﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateZip
{
    public class Zip
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileToZips">文件路径</param>
        /// <param name="zipedFile">压缩后的文件名</param>
        public static string ZipFile(List<string> fileToZips, string zipedFile)
        {
            try
            {
                using (Ionic.Zip.ZipFile zip = new Ionic.Zip.ZipFile(zipedFile, Encoding.Default))
                {
                    foreach (string fileToZip in fileToZips)
                    {
                        using (FileStream fs = new FileStream(fileToZip, FileMode.Open, FileAccess.ReadWrite))
                        {
                            byte[] buffer = new byte[fs.Length];
                            fs.Read(buffer, 0, buffer.Length);
                            string fileName = fileToZip.Substring(fileToZip.LastIndexOf("\\") + 1);
                            zip.AddEntry(fileName, buffer);
                        }
                    }
                    zip.Save();
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
    }
}
