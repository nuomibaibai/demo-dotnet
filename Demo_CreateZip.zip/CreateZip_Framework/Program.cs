﻿using CreateZip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateZip_Framework
{
    class Program
    {
        static void Main(string[] args)
        {

            ///用来生成历峰的zip文件
            string path = @"F:\HudsonHU\Gitee项目\历峰\sales-cut-off\客户数据\BI Sales Data 202010-202202";

            List<string> fileList = new List<string>();

            DirectoryInfo directoryInfo = new DirectoryInfo(path);

            foreach (var directory in directoryInfo.GetFiles())
            {
                string Extension = Path.GetExtension(directory.FullName);
                if (Extension == ".xlsx")
                {
                    fileList.Add(directory.FullName);
                }
            }

            foreach (var file in fileList)
            {
                var filename = Path.GetFileName(file);
                var filepath = Path.GetFullPath(file);
                //Console.WriteLine(filename);

                //Console.WriteLine(filename.Length - 1);

                var date = filename.Substring(3, filename.Length - 3);

                date = date.Replace(" BI Sales report ", "");

                //Console.WriteLine(date);
                var str = "";

                if (date.IndexOf('-') > 0)
                {
                    var date1 = date.Split('-')[0];
                    DateTime dateTime1 = new DateTime(int.Parse(date1.Substring(0, 4)), int.Parse(date1.Substring(4, 2)), 1);
                    dateTime1 = dateTime1.AddMonths(1).AddDays(-1);
                    str += dateTime1.ToString("yyyyMMdd");
                    str += "-";
                    var date2 = date.Split('-')[1];

                    if (date2.Length == 2)
                    {
                        date2 = date1.Substring(0, 4) + date2;
                    }

                    DateTime dateTime2 = new DateTime(int.Parse(date2.Substring(0, 4)), int.Parse(date2.Substring(4, 2)), 1);
                    dateTime2 = dateTime2.AddMonths(1).AddDays(-1);
                    str += dateTime2.ToString("yyyyMMdd");
                }
                else
                {
                    var date1 = date;
                    DateTime dateTime = new DateTime(int.Parse(date1.Substring(0, 4)), int.Parse(date1.Substring(4, 2)), 1);
                    dateTime = dateTime.AddMonths(1).AddDays(-1);
                    str = dateTime.ToString("yyyyMMdd");
                }
                //Console.WriteLine(str);

                var filedir = Path.GetDirectoryName(file);
                //Console.WriteLine(filedir);

                var zipname = Path.Combine(filedir, $"{str}_{filename.Substring(0, 3)}.zip");

                //Console.WriteLine(zipname);

                if (!File.Exists(zipname))
                {
                    var result = Zip.ZipFile(new List<string>() { filepath }, zipname);
                    if (result == "")
                    {
                        Console.WriteLine(zipname + ",完成!");
                    }
                    else
                    {
                        Console.WriteLine(result);
                    }
                }
            }
        }
    }
}
