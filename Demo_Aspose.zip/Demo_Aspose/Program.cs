﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using Aspose.Cells;

namespace Demo_Aspose
{
    class Program
    {
        static void Main(string[] args)
        {
            Import();

            //Export();
        }

        private static Workbook _workbook = null;

        private static void Import()
        {
            List<DataTable> dataTables = new();
            try
            {
                var filenames = Directory.GetFiles(@"E:\Desktop\test\xlsx");
                foreach (var filename in filenames)
                {
                    _workbook = new(filename);
                    var worksheet = _workbook.Worksheets[0];
                    var cells = worksheet.Cells;
                    dataTables.Add(cells.ExportDataTableAsString(0, 0, cells.MaxDataRow + 1, cells.MaxDataColumn + 1));
                    Console.WriteLine(filename);
                }
                Console.WriteLine($"导入完成!总计【{dataTables.Count}】");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"导入失败!总计【{dataTables.Count}】,{ex.Message}");
            }
        }

        private static void Export()
        {
            try
            {
                Console.WriteLine("开始！");
                for (int i = 0; i <= 100; i++)
                {
                    string filename = $@"E:\Desktop\test\xlsx\table_{i}_{Guid.NewGuid()}.xlsx";
                    Workbook workbook = new();
                    var worksheet = workbook.Worksheets[0];
                    worksheet.Name = $"SheetName";
                    var cells = worksheet.Cells;

                    for (int j = 0; j < 10; j++)
                    {
                        cells[0, j].PutValue($"col_{0}_{j}");

                        for (int k = 0; k < 100; k++)
                        {
                            cells[k + 1, j].PutValue($"row_{k + 1}_{j}");
                        }
                    }
                    
                    workbook.Save(filename);
                    Console.WriteLine($"导出完成!{Path.GetFileName(filename)}");
                }
                Console.WriteLine("结束!");

            }
            catch (Exception ex)
            {
                Console.WriteLine("导出失败!" + ex.Message);
            }
        }
    }
}
