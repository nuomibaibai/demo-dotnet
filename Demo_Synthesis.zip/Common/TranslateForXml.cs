﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;

namespace Common
{
    public class TranslateForXml
    {
        public TranslateForXml() { }


        /// <summary>
        /// 读取当前用户的xml配置
        /// </summary>
        /// <param name="infile"></param>
        /// <param name="nodeName"></param>
        /// <param name="outAtt"></param>
        /// <returns></returns>
        public Dictionary<string, DataTable> ReadeXmlAllSetting(string XmlPath, string UserID)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(XmlPath);
            XmlNodeList parentNodeList = doc.DocumentElement.ChildNodes;
            if (parentNodeList == null)
                return null;


            Dictionary<string, DataTable> dic = new Dictionary<string, DataTable>();

            foreach (XmlNode item in parentNodeList)
            {
                if (item.Attributes["UserID"].Value.ToString() == UserID)
                {
                    foreach (XmlNode child in item)
                    {
                        DataTable dt = new DataTable();
                        dt.Columns.Add("TableName");
                        dt.Columns.Add("EnglishName");
                        dt.Columns.Add("ChineseName");
                        dt.Columns.Add("strWhere");
                        foreach (XmlNode lastchild in child)
                        {
                            DataRow dr = dt.NewRow();
                            dr[0] = child.Attributes["TableName"].Value.ToString().Trim();
                            dr[1] = lastchild.Attributes.GetNamedItem("EnglishName").Value.ToString();
                            dr[2] = lastchild.Attributes.GetNamedItem("ChineseName").Value.ToString();
                            dr[3] = lastchild.Attributes.GetNamedItem("strWhere").Value.ToString();
                            dt.Rows.Add(dr);
                        }
                        dic.Add(child.Attributes["TableName"].Value.ToString().Trim(), dt);
                    }
                    break;
                }
            }
            return dic;
        }

        /// <summary>
        /// 读取当前用户的最新xml配置
        /// </summary>
        /// <param name="infile"></param>
        /// <param name="nodeName"></param>
        /// <param name="outAtt"></param>
        /// <returns></returns>
        public DataTable ReadeXmlNowSetting(string XmlPath, string UserID)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(XmlPath);
           string TableName = "";
            XmlNodeList childnode = null;
            XmlNodeList parentNodeList = doc.DocumentElement.ChildNodes;
            if (parentNodeList == null)
                return null;
            foreach (XmlNode item in parentNodeList)
            {
                if (item.Attributes["UserID"].Value.ToString() == UserID)
                {
                    TableName = item.Attributes["NewTableName"].Value.ToString();
                    foreach (XmlNode child in item)
                    {
                        if (TableName == child.Attributes["TableName"].Value.ToString().Trim())
                        {
                            childnode = child.ChildNodes;
                        }
                    }
                }
                #region
                //if (xn.Attributes["UserID"].Value.ToString() == UserID)
                //{
                //    TableName = xn.Attributes["NewTableName"].Value.ToString();
                //    XmlNodeList xmllist = xn.SelectNodes("//TranslateTable[@TableName='" + TableName + "']")[0].ChildNodes;
                //    if (xn.SelectNodes("//TranslateTable[@TableName='" + TableName + "']").Count == 0)
                //        return null;
                //    childnode = xn.SelectNodes("//TranslateTable[@TableName='" + TableName + "']")[0].ChildNodes;
                //    break;
                //}
                #endregion
            }
            if (TableName.Trim() == "" || childnode == null)
                return null;

            DataTable dt = new DataTable();
            dt.Columns.Add("TableName");
            dt.Columns.Add("EnglishName");
            dt.Columns.Add("ChineseName");
            dt.Columns.Add("strWhere");
            foreach (XmlNode item in childnode)
            {
                DataRow dr = dt.NewRow();
                dr[0] = TableName;
                dr[1] = item.Attributes.GetNamedItem("EnglishName").Value.ToString();
                dr[2] = item.Attributes.GetNamedItem("ChineseName").Value.ToString();
                dr[3] = item.Attributes.GetNamedItem("strWhere").Value.ToString();
                dt.Rows.Add(dr);
            }
            return dt;
        }

        /// <summary>
        /// 删除指定的XML节点
        /// </summary>
        /// <param name="XmlPath"></param>
        /// <param name="UserID"></param>
        /// <param name="TableName"></param>
        /// <returns></returns>
        public bool DeleteXmlSetting(string XmlPath, string UserID, string TableName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(XmlPath);
            XmlNodeList parentNodeList = doc.DocumentElement.ChildNodes;
            if (parentNodeList == null)
                return false;
            foreach (XmlNode item in parentNodeList)
            {
                if (item.Attributes["UserID"].Value.ToString() == UserID)
                {
                    foreach (XmlNode child in item)
                    {
                        if (TableName == child.Attributes["TableName"].Value.ToString().Trim())
                        {
                            for (int i = child.ChildNodes.Count - 1; i >= 0; i--)
                            {
                                child.RemoveChild(child.ChildNodes[i]);
                            }
                            doc.Save(XmlPath);
                            return true;
                        }
                    }
                    break;
                }
            }
            return true;
        }

        public bool AddXmlSetting(string XmlPath, string UserID, string TableName, string EnglishName, string ChineseName, string strWhere)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(XmlPath);
            XmlNodeList parentNodeList = doc.DocumentElement.ChildNodes;
            if (parentNodeList == null)
                return false;

            bool IsHaveItemNode = false;
            bool IsHaveTranslateTableNode = false;
            XmlElement UserNode = null;
            XmlElement TranslateTableNode = null;
            XmlElement FieldNode = null;

            foreach (XmlElement item in parentNodeList)
            {
                if (item.Attributes["UserID"].Value.ToString() == UserID)
                {
                    IsHaveItemNode = true;
                    UserNode = item;
                    UserNode.SetAttribute("NewTableName", TableName);
                    foreach (XmlElement child in item)
                    {
                        if (TableName == child.Attributes["TableName"].Value.ToString().Trim())
                        {
                            IsHaveTranslateTableNode = true;
                            TranslateTableNode = child;
                            break;
                        }
                    }
                    break;
                }
            }
            if (!IsHaveItemNode)
            {
                UserNode = doc.CreateElement("User");
                UserNode.SetAttribute("UserID", UserID);
                UserNode.SetAttribute("NewTableName", TableName);
                doc.DocumentElement.AppendChild(UserNode);
            }
            if (!IsHaveTranslateTableNode)
            {
                TranslateTableNode = doc.CreateElement("TranslateTable");
                TranslateTableNode.SetAttribute("TableName", TableName);
                UserNode.AppendChild(TranslateTableNode);
            }
            FieldNode = doc.CreateElement("Field");
            FieldNode.SetAttribute("EnglishName", EnglishName);
            FieldNode.SetAttribute("ChineseName", ChineseName);
            FieldNode.SetAttribute("strWhere", strWhere);

            TranslateTableNode.AppendChild(FieldNode);
            doc.Save(XmlPath);

            return true;
        }
    }
}
