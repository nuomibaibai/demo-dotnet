﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public class ReplaceSql
    {
        public static string Replace(string sqlstr)
        {
            string[] sqlKeyWords = { "'", "\"","%", "()", "<>", ";", "-", "+", "select", "delete"
                                       , "drop", "alter", "update", "add", "cursor", "and", "or",
                                       "as", "union", "join" };

            string returnSql = sqlstr;
            foreach (string item in sqlKeyWords)
            {
                returnSql = sqlstr.ToLower().Replace(item.ToLower(), string.Empty);

            }
            return returnSql;
        }

        public static string ReplaceV2(string sqlstr)
        {
            string[] sqlKeyWords = { "'", "\"","%", "()", "<>", ";", "-", "+", "select", "delete"
                                       , "drop", "alter", "update", "add", "cursor", "and", "or",
                                       "as", "union", "join" };

            string returnSql = sqlstr;
            foreach (string item in sqlKeyWords)
            {
                returnSql = sqlstr.ToLower().Replace(item.ToLower(), string.Empty);

            }
            return returnSql;
        }
    }
}
