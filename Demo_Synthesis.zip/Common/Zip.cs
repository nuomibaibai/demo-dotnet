﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ionic.Zip;
using System.IO;
namespace Common
{
    public class Zip
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileToZips">文件路径</param>
        /// <param name="zipedFile">压缩后的文件名</param>
        public static string   ZipFile(List<string> fileToZips, string zipedFile)
        {
            try
            {
                using (Ionic.Zip.ZipFile zip = new Ionic.Zip.ZipFile(zipedFile, Encoding.Default))
                {
                    foreach (string fileToZip in fileToZips)
                    {
                        using (FileStream fs = new FileStream(fileToZip, FileMode.Open, FileAccess.ReadWrite))
                        {
                            byte[] buffer = new byte[fs.Length];
                            fs.Read(buffer, 0, buffer.Length);
                            string fileName = fileToZip.Substring(fileToZip.LastIndexOf("\\") + 1);
                            zip.AddEntry(fileName, buffer);
                        }
                    }
                    zip.Save();
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.ToString ();
            }
        }

        //public static void ZipFiles(List<string> fileToZips, string zipedFile)
        //{

        //    try
        //    {
        //        using (ZipOutputStream s = new ZipOutputStream(File.Create(zipedFile)))
        //        {

        //            s.SetLevel(9); // 压缩级别 0-9
        //            //s.Password = "123"; //Zip压缩文件密码
        //            byte[] buffer = new byte[4096]; //缓冲区大小
        //            foreach (string file in fileToZips)
        //            {
        //                ZipEntry entry = new ZipEntry(Path.GetFileName(file));
        //                entry.DateTime = DateTime.Now;
        //                s.PutNextEntry(entry);
        //                using (FileStream fs = File.OpenRead(file))
        //                {
        //                    int sourceBytes;
        //                    do
        //                    {
        //                        sourceBytes = fs.Read(buffer, 0, buffer.Length);
        //                        s.Write(buffer, 0, sourceBytes);
        //                    } while (sourceBytes > 0);
        //                }
        //            }
        //            s.Finish();
        //            s.Close();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Exception during processing {0}", ex);
        //    }
        //}

    }
}
