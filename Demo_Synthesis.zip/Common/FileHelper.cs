﻿using PdfiumViewer;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class FileHelper
    {
        /// <summary>
        /// 创建文件夹
        /// </summary>
        /// <param name="TargetPath">文件路径</param>
        public static void CreateFolder(string TargetPath)
        {
            try
            {
                if (!Directory.Exists(TargetPath))//如果不存在就创建file文件夹
                Directory.CreateDirectory(TargetPath);
            }
            catch (Exception ex)
            {
                
            }
        }

        /// <summary>
        /// 若不存在文件
        /// </summary>
        /// <param name="SavePath">保存的路径</param>
        /// <param name="FileName">文件名</param>
        /// <param name="Extension">后缀名</param>
        /// <param name="index">重复下标</param>
        /// <returns></returns>
        public static bool IsFileNotExists(string SavePath, string FileName, string Extension, ref int index)
        {
            string Newfilename = Path.Combine(SavePath, $"{FileName}_{index}{Extension}");
            if (File.Exists(Newfilename))
            {
                index++;
                return IsFileNotExists(SavePath, FileName, Extension, ref index);
            }
            else
            {
                return true;
            }
        }

        
    }
}
