﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
//using System.Web.Script.Serialization;
using System.Collections;
using System.Text.RegularExpressions;
using System.IO;

namespace Common
{
    public class CommonHelp
    {

        #region 方法[JsonToDataTable]Json转化为Datatable形式
        public static DataTable ToDataTable(string strJson)
        {
            //strJson = "[{\"CATG_CODE\":\"moon1204001\",\"GAAP_TYPE\":\"PRC\",\"DePREcode\":\"Double\",\"Ser_life\":\"60\",\"Active\":\"1\",\"DepreDateFactor\":\"0\",\"DepreStartPeriod\":\"201912\",\"DepreLstPeriod\":\"\",\"NetResidualRate\":\"5.00\",\"NET_RESI_VAL\":\"1000.00\",\"Curr_amt\":\"3316.67\",\"Deprenum\":\"0\",\"Depr_amt\":\"0.00\",\"DepreSingle\":\"666.67\",\"DepreCurmonth\":\"316.67\",\"DepreCurYear\":\"0.00\",\"origin_value\":\"20000.00\",\"addvalue\":\"3010.00\",\"decvalue\":\"11.00\",\"decprepare\":\"0.00\"},{\"CATG_CODE\":\"moon1204001\",\"GAAP_TYPE\":\"TAX\",\"DePREcode\":\"Straight\",\"Ser_life\":\"60\",\"Active\":\"1\",\"DepreDateFactor\":\"0\",\"DepreStartPeriod\":\"201912\",\"DepreLstPeriod\":\"\",\"NetResidualRate\":\"5.00\",\"NET_RESI_VAL\":\"1000.00\",\"Curr_amt\":\"3316.67\",\"Deprenum\":\"0\",\"Depr_amt\":\"0.00\",\"DepreSingle\":\"323.45\",\"DepreCurmonth\":\"316.67\",\"DepreCurYear\":\"0.00\",\"origin_value\":\"20000.00\",\"addvalue\":\"3020.00\",\"decvalue\":\"21.00\",\"decprepare\":\"0.00\"}]";
            ////取出表名
            Regex rg = new Regex(@"(?<={)[^:]+(?=:\[)", RegexOptions.IgnoreCase);
            string strName = rg.Match(strJson).Value;
            DataTable tb = null;
            string Str_Head = "";

            ////去除表名
            //strJson = strJson.Substring(strJson.IndexOf("[") + 1);
            //strJson = strJson.Substring(0, strJson.IndexOf("]"));

            //获取数据
            rg = new Regex(@"(?<={)[^}]+(?=})");
            MatchCollection mc = rg.Matches(strJson);
            for (int i = 0; i < mc.Count; i++)
            {
                string strRow = mc[i].Value;
                string[] strRows = strRow.Split(',');

                //创建表
                if (tb == null)
                {
                    tb = new DataTable();
                    tb.TableName = strName;
                    foreach (string str in strRows)
                    {
                        DataColumn dc = new DataColumn();
                        string[] strCell = str.Split(':');

                        Str_Head = strCell[0].ToString().Substring(0, strCell[0].ToString().Length - 1);//去除最后一位字符串
                        Str_Head = Str_Head.Substring(1);//去除第一位字符串
                        dc.ColumnName = Str_Head;
                        //dc.ColumnName = strCell[0].ToString();

                        tb.Columns.Add(dc);
                    }
                    tb.AcceptChanges();
                }

                //增加内容
                DataRow dr = tb.NewRow();
                for (int r = 0; r < strRows.Length; r++)
                {
                    //Str_Cell = strRows[r].Split(':')[1].Trim().Replace("，", ",").Replace("：", ":").Replace("/", "").Substring(0, strRows[1].ToString().Length - 1);
                    //Str_Cell = Str_Cell.Substring(1);
                    //dr[r] = Str_Cell;
                    dr[r] = strRows[r].Split(':')[1].Trim().Replace("，", ",").Replace("：", ":").Replace("/", "").Replace("\"","");
                    //dr[r] = dr[r].ToString().Substring(0, Convert.ToString(dr[r]).Length - 1);//去除最后一位字符串
                    //dr[r] = Convert.ToString(dr[r]).Substring(1);//去除第一位字符串
                }
                tb.Rows.Add(dr);
                tb.AcceptChanges();
            }

            return tb;
        }
        #endregion

        #region 方法json字符串处理成updatesql
        public static string[] jsonarayToDataTable(string strJson)
        {
            ////取出表名
            Regex rg = new Regex(@"(?<={)[^:]+(?=:\[)", RegexOptions.IgnoreCase);
            string strName = rg.Match(strJson).Value;
            ArrayList sqllist=new ArrayList ();

            ////去除表名
            strJson = strJson.Substring(strJson.IndexOf("[") + 1);
            strJson = strJson.Substring(0, strJson.IndexOf("]}"));

            //获取数据
            strJson = strJson.Replace("\"", "");
            string[] dtstring = strJson.Split('[');
            return dtstring;
        }
        #endregion

        public static decimal GetdecimalValue(object str)
        {
            decimal value = 0;
            try
            {
                value = Convert.ToDecimal(str);
            }
            catch (Exception)
            {
                
            }
            return value;
        }

        public static int GetintValue(object str)
        {
            int value = 0;
            try
            {
                value = Convert.ToInt32(str);
            }
            catch (Exception)
            {

            }
            return value;
        }

        public static string GetDocdate(string year, string month)
        {
            int y = Convert.ToInt32(year);
            int m = Convert.ToInt32(month);
            int d = DateTime.Now.Day;
            int maxday = 0;
            int[] maxdayarr = { 28,29,30,31 };
            switch (m)
            {
                case 1:
                    maxday = maxdayarr[3];
                    break;
                case 2:
                    if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)
                    {
                        maxday = maxdayarr[1];
                    }
                    else
                    {
                        maxday = maxdayarr[0];
                    }
                    break;
                case 3:
                    maxday = maxdayarr[3];
                    break;
                case 4:
                    maxday = maxdayarr[2];
                    break;
                case 5:
                    maxday = maxdayarr[3];
                    break;
                case 6:
                    maxday = maxdayarr[2];
                    break;
                case 7:
                    maxday = maxdayarr[3];
                    break;
                case 8:
                    maxday = maxdayarr[3];
                    break;
                case 9:
                    maxday = maxdayarr[2];
                    break;
                case 10:
                    maxday = maxdayarr[3];
                    break;
                case 11:
                    maxday = maxdayarr[2];
                    break;
                case 12:
                    maxday = maxdayarr[3];
                    break;
            }
            d = d >= maxday ? maxday : d;
            return y.ToString() + Dis10Fill0(m) + Dis10Fill0(d) ;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str">字符串</param>
        /// <param name="substring">子串</param>
        /// <returns></returns>
        public static int SubstringCount(string str, string substring)
        {
            if (str.Contains(substring))
            {
                string strReplaced = str.Replace(substring, "");
                return (str.Length - strReplaced.Length) / substring.Length;
            }
            return 0;
        }

        /// <summary>
        /// 不满10则补0
        /// </summary>
        /// <param name="str">值</param>
        /// <returns></returns>
        public static string Dis10Fill0(int str)
        {
            return str < 10 ? "0" + str.ToString() : str.ToString();
        }

        /// <summary>
        /// 获取当前日期（例：2019-01-01）
        /// </summary>
        public static string Getdate()
        {
            DateTime dt = DateTime.Now;
            int y = dt.Year;
            int m = dt.Month;
            int d = dt.Day;
            return (y.ToString() + '-' + (m < 10 ? ("0" + m).ToString() : m.ToString()) + '-' + (d < 10 ? ("0" + d).ToString() : d.ToString())).ToString();
        }

        /// <summary>
        /// 获取当前日期yyyy-MM-dd HH:mm:ss（例：2019-01-01 09:32:50）
        /// </summary>
        public static string Getdate2()
        {
            DateTime dt = DateTime.Now;
            int y = dt.Year;
            int m = dt.Month;
            int d = dt.Day;
            int h = dt.Hour;
            int min = dt.Minute;
            int s = dt.Second;
            return (y.ToString() + '-' + (m < 10 ? ("0" + m).ToString() : m.ToString()) + '-' + (d < 10 ? ("0" + d).ToString() : d.ToString()) + " " + (h < 10 ? ("0" + h).ToString() : h.ToString()) + ":" + (min < 10 ? ("0" + min).ToString() : min.ToString()) + ":" + (s < 10 ? ("0" + s).ToString() : s.ToString())).ToString();
        }

        public static string Getdate(string format = "yyyyMMdd")
        {
            DateTime dt = DateTime.Now;
            int y = dt.Year;
            int m = dt.Month;
            int d = dt.Day;
            string returnvalue = "";
            switch (format)
            {
                case "yyyyMMdd":
                    returnvalue = y.ToString() + Dis10Fill0(m) + Dis10Fill0(d);
                    break;
                case "yyyyMM":
                    returnvalue = y.ToString() + Dis10Fill0(m);
                    break;
                case "yyyy":
                    returnvalue = y.ToString();
                    break;
                default:
                    returnvalue = y.ToString() + '-' + Dis10Fill0(m) + '-' + Dis10Fill0(d);
                    break;
            }
            return returnvalue;
        }

        /// <summary>
        /// 根据字符串获取数组
        /// </summary>
        /// <param name="value">字符串</param>
        /// <param name="zf">截取字符</param>
        /// <returns></returns>
        public static string[] GetArr(string value, char zf)
        {
            string[] arr;
            if (value.IndexOf(zf) > -1)
            {
                arr = value.Split(zf);
            }
            else
            {
                arr = new string[] { "" };
                arr[0] = value;
            }
            return arr;
        }

        /// <summary>
        /// 时间戳20190101010101123
        /// </summary>
        /// <param name="head">前缀</param>
        /// <returns></returns>
        public static string GetDocno(string head)
        {
            string str = DateTime.Now.ToString("yyyyMMddHHmmssfff");
            return head + str;
        }

        /// <summary>
        /// 时间戳 20190101010101
        /// </summary>
        /// <param name="format">转换的格式</param>
        /// <returns></returns>
        public static string GetDocno1(string format)
        {
            string str = "";
            try
            {
                str = DateTime.Now.ToString(format);
            }
            catch (Exception)
            {
                str = DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            return str;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt">源表</param>
        /// <param name="Colu">源字段</param>
        /// <param name="Value">源字段的值</param>
        /// <param name="TempColu">目的字段</param>
        /// <returns>目的字段的值</returns>
        public static string BasicColuGetOtherColu(DataTable dt, string Colu, string Value, string TempColu)
        {
            DataRow[] drl = dt.Select("" + Colu + "='" + Value + "'");
            if (drl.Count() > 0)
            {
                return drl[0][TempColu].ToString();
            }
            else
            {
                return "";
            }
        }

        public static bool ValidateRequestInput(string input)
        {

            string[] keyWords = { "'", "\"", "%", "()", "<>", ";", "+", "select", "delete", "drop", "alter", "update", "add", "CURSOR", "and", "or", "AS", "union", "join" };


            //string[] keyWords = { "'", "\"", "%", "()", "<>", ";", "-", "+", "select", "delete", "drop", "alter", "update", "add", "CURSOR", "and", "or", "AS","union","join" };

            foreach (string word in keyWords)
            {
                if (input.ToLower().Contains(word))
                {
                    return false;
                }
            }
            return true;
        }


        public static string BytesToHexString(byte[] input)
        {
            StringBuilder hexString = new StringBuilder(64);

            for (int i = 0; i < input.Length; i++)
            {
                hexString.Append(String.Format("{0:X2}", input[i]));
            }
            return hexString.ToString();
        }

        public static byte[] HexStringToBytes(string hex)
        {
            if (hex.Length == 0)
            {
                return new byte[] { 0 };
            }

            if (hex.Length % 2 == 1)
            {
                hex = "0" + hex;
            }

            byte[] result = new byte[hex.Length / 2];

            for (int i = 0; i < hex.Length / 2; i++)
            {
                result[i] = byte.Parse(hex.Substring(2 * i, 2), System.Globalization.NumberStyles.AllowHexSpecifier);
            }

            return result;
        }

        public static object GetValueByType(Type type)
        {
            object value = null;
            if (type == typeof(int))
            {
                value = GetintValue(0);
            }
            else if (type == typeof(decimal))
            {
                value = GetdecimalValue(0);
            }
            else
            {
                value = string.Empty;
            }
            return value;
        }

        public static object GetValueByType(Type type, object oldvalue)
        {
            object value = null;
            if (type == typeof(int))
            {
                value = GetintValue(oldvalue);
            }
            else if (type == typeof(decimal))
            {
                value = GetdecimalValue(oldvalue);
            }
            else
            {
                value = ReplaceSql.Replace(oldvalue.ToString().Trim());
            }
            return value;
        }
    }
}
