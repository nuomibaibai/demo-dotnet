﻿using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Demo_API
{
    class Program
    {
        public static string Textin_MoreOCR_Host = "https://api.textin.com";
        public static string Textin_MoreOCR_Path = "/robot/v1.0/api/bills_crop";
        public static string Textin_MoreOCR_appId = "8df66b56ca9baaf24fa3ef36f5391e0c";
        public static string Textin_MoreOCR_secretCode = "327b494479e352476381b8ecdf960706";
        public static string imgpath = @"E:\Desktop\发票文件\test5.jpg";
        public static bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }
        static void Main(string[] args)
        {
            try
            {
                HttpWebRequest httpRequest = null;
                HttpWebResponse httpResponse = null;
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(CheckValidationResult);
                string url = Textin_MoreOCR_Host + Textin_MoreOCR_Path;
                httpRequest = (HttpWebRequest)WebRequest.CreateDefault(new Uri(url));
                httpRequest.Method = "POST";
                //根据API的要求，定义相对应的Content-Type
                httpRequest.ContentType = "application/json; charset=UTF-8";
                httpRequest.Headers.Add("appId", Textin_MoreOCR_appId);
                httpRequest.Headers.Add("secretCode", Textin_MoreOCR_secretCode);

                using (FileStream fs = new FileStream(imgpath, FileMode.Open))
                {
                    BinaryReader br = new BinaryReader(fs);
                    byte[] contentBytes = br.ReadBytes(Convert.ToInt32(fs.Length));
                    using (Stream stream = httpRequest.GetRequestStream())
                        stream.Write(contentBytes, 0, contentBytes.Length);
                }
                try
                {
                    httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                }
                catch (WebException ex)
                {
                    httpResponse = (HttpWebResponse)ex.Response;
                }
                Stream st = httpResponse.GetResponseStream();
                StreamReader reader = new StreamReader(st, Encoding.GetEncoding("utf-8"));
                Console.WriteLine(reader.ReadToEnd());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
