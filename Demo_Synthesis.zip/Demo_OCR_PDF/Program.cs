﻿using System;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace Demo_OCR_PDF
{
    class Program
    {
        static void Main(string[] args)
        {

            //Getbase64();
            OCRPDF();
        }

        private static void Getbase64()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            FileSystemInfo[] fsinfos = directoryInfo.GetFileSystemInfos();
            using (StreamWriter sw = File.AppendText("test.txt"))
            {
                foreach (var NextFile in fsinfos)
                {
                    string Extension = System.IO.Path.GetExtension(NextFile.FullName);
                    string FileName = System.IO.Path.GetFileName(NextFile.FullName);

                    if (Extension.ToLower().Equals(".pdf"))
                    {
                        using (FileStream fs = new FileStream(NextFile.FullName, FileMode.Open))
                        {
                            BinaryReader br = new BinaryReader(fs);
                            byte[] contentBytes = br.ReadBytes(Convert.ToInt32(fs.Length));
                            string base64 = Convert.ToBase64String(contentBytes);
                            sw.WriteLine($"{base64}");
                        }
                        Console.WriteLine($"文件{FileName}已识别");
                        //sw.WriteLine($"\n\r文件{FileName}已识别\n\r");
                    }
                }
            }
        }

        private static void OCRPDF()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            FileSystemInfo[] fsinfos = directoryInfo.GetFileSystemInfos();
            using (StreamWriter sw = File.AppendText("test.txt"))
            {
                foreach (var NextFile in fsinfos)
                {
                    string Extension = System.IO.Path.GetExtension(NextFile.FullName);
                    string FileName = System.IO.Path.GetFileName(NextFile.FullName);

                    if (Extension.ToLower().Equals(".pdf"))
                    {
                        PdfReader reader = new PdfReader(FileName);

                        if (reader == null || reader.NumberOfPages == 0)
                        {
                            return;
                        }

                        //获取pdf总页数
                        var totalPage = reader.NumberOfPages;

                        PdfReaderContentParser parser = new PdfReaderContentParser(reader);
                        //string word = "";
                        for (int i = 1; i <= totalPage; i++)
                        {
                            ITextExtractionStrategy strategy = parser.ProcessContent(i, new SimpleTextExtractionStrategy());
                            //将文本内容赋值给一个富文本框
                            sw.WriteLine($"{strategy.GetResultantText()}");
                            sw.Flush();
                            //word += strategy.GetResultantText();
                        }
                        // string[] arr = word.Split('\n');
                        Console.WriteLine($"文件{FileName}已识别");
                        //sw.WriteLine($"\n\r文件{FileName}已识别\n\r");
                    }
                }
            }
        }
    }
}
