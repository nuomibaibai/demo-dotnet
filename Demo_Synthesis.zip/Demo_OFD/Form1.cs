﻿using ICSharpCode.SharpZipLib.GZip;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using XML;
using Zip;

namespace Demo_OFD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
            Application.Exit();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "OFD文件|*.OFD;*.ofd";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                //FileName：显示文件路径+名字
                this.txtSelect.Text = dialog.FileName;
            }
        }

        public void GetXmlNode(XmlNode xmlNode)
        {
            if (xmlNode.ChildNodes != null)
            {
                foreach (XmlNode item in xmlNode)
                {
                    if (item.HasChildNodes)
                    {
                        BindListBoxMsg(lbMsg, $"名称：【{item.Name}】");
                        BindListBoxMsg(lbMsg, $"内容：【{item.InnerText}】");
                        BindListBoxMsg(lbMsg, $"-------------------------------");
                        GetXmlNode(item);
                    }
                }
            }
        }

        List<string> xmllist = new List<string>() { "original_invoice.xml", "content.xml" };
        public void Director(string FullName)
        {
            DirectoryInfo d = new DirectoryInfo(FullName);
            FileSystemInfo[] fsinfos = d.GetFileSystemInfos();
            foreach (FileSystemInfo NextFile in fsinfos)
            {
                if (NextFile is DirectoryInfo)     //判断是否为文件夹
                    Director(NextFile.FullName);//递归调用
                else
                {
                    string Extension = Path.GetExtension(NextFile.FullName);
                    if (Extension.ToLower().Equals(".xml"))
                    {
                        if (xmllist.Contains(Path.GetFileName(NextFile.FullName).ToLower()))
                        {
                            XmlDocument xmldoc = new XmlDocument();
                            try
                            {
                                xmldoc.Load($@"{NextFile.FullName}");
                                XmlNodeList parentNodeList = xmldoc.DocumentElement.ChildNodes;

                                BindListBoxMsg(lbMsg, $"===========================================");
                                BindListBoxMsg(lbMsg, $"文件名称：【{NextFile.FullName}】");

                                foreach (XmlNode item in parentNodeList)
                                {
                                    BindListBoxMsg(lbMsg, $"名称：【{item.Name}】");
                                    BindListBoxMsg(lbMsg, $"内容：【{item.InnerText}】");
                                    BindListBoxMsg(lbMsg, $"-------------------------------");
                                    GetXmlNode(item);
                                }
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                }
            }
        }

        private void BindListBoxMsg(ListBox lb, string msg)
        {
            lb.Items.Add(msg);
            lb.TopIndex = lb.Items.Count - 1;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            Thread th = new Thread(() =>
            {
                try
                {

                    string path = this.txtSelect.Text;
                    string newpath = $@"{Path.GetDirectoryName(path) }\{ Path.GetFileNameWithoutExtension(path)}.zip";
                    string newFolder = $@"{Path.GetDirectoryName(path) }\{ Path.GetFileNameWithoutExtension(path)}";

                    if (!File.Exists(newpath))
                        File.Copy(path, newpath);

                    if (!Directory.Exists(newFolder))
                        ZipHelper.UnZip(newpath, "");

                    Director(newFolder);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                MessageBox.Show("OK");
            }
            );
            th.Start();

            /*
                 <?xml version="1.0" encoding="UTF-8"?>

-<ofd:OFD Version="1.1" DocType="OFD" xmlns:ofd="http://www.ofdspec.org/2016">


-<ofd:DocBody>


-<ofd:DocInfo>

<ofd:DocID>bc5a444d512940bb8f7ab474204c45d1</ofd:DocID>

<ofd:Author>China Tax</ofd:Author>

<ofd:CreationDate>2020-09-22</ofd:CreationDate>


-<ofd:CustomDatas>

<ofd:CustomData Name="template-version">1.0.20.0422</ofd:CustomData>

<ofd:CustomData Name="native-producer">SuwellFormSDK</ofd:CustomData>

<ofd:CustomData Name="producer-version">1.0.20.0603</ofd:CustomData>

<ofd:CustomData Name="发票代码">011002000411</ofd:CustomData>

<ofd:CustomData Name="发票号码">21514013</ofd:CustomData>

<ofd:CustomData Name="合计税额">4.29</ofd:CustomData>

<ofd:CustomData Name="合计金额">428.71</ofd:CustomData>

<ofd:CustomData Name="开票日期">2020年08月23日</ofd:CustomData>

<ofd:CustomData Name="校验码">01439 10043 72613 51866</ofd:CustomData>

<ofd:CustomData Name="购买方纳税人识别号">9111010859388391XB</ofd:CustomData>

<ofd:CustomData Name="销售方纳税人识别号">91110114MA01NWPQ2Q</ofd:CustomData>

</ofd:CustomDatas>

</ofd:DocInfo>

<ofd:DocRoot>Doc_0/Document.xml</ofd:DocRoot>

<ofd:Signatures>Doc_0/Signs/Signatures.xml</ofd:Signatures>

</ofd:DocBody>

</ofd:OFD>
                 */
        }
    }
}
