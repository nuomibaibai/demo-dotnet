﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_Tasks
{
    class Program
    {
        static void Main(string[] args)
        {   
            //多线程并发
            List<int> list = new();
            for (int i = 1; i <= 100; i++)
            {
                list.Add(i);
            }
            Stopwatch stopwatch = new();
            stopwatch.Start();

            static void action(int i)
            {
                Console.WriteLine($"第{i}条,{Thread.CurrentThread.ManagedThreadId:00}");
                Thread.Sleep(new Random(i).Next(100, 300));
            }

            List<Task> tasks = new();
            foreach (var i in list)
            {
                int k = i;
                tasks.Add(Task.Run(() => action(k)));
                if (tasks.Count > 10)//控制线程数量
                {
                    Task.WaitAny(tasks.ToArray());
                    tasks = tasks.Where(t => t.Status != TaskStatus.RanToCompletion).ToList();
                }
            }
            Task.WhenAll(tasks.ToArray()).ContinueWith(t =>
            {
                Console.WriteLine($"所有线程已执行完成");
            }).Wait();
            stopwatch.Stop();
            Console.WriteLine($"线程运行时间:【{stopwatch.ElapsedMilliseconds}】");
        }
    }
}
