﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech;
using System.Speech.Synthesis;

namespace Demo_IVR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SpeechSynthesizer speech = new SpeechSynthesizer())
                {
                    //同步朗读文本
                    //speech.Speak(richTextBox1.Text);
                    //speech.GetInstalledVoices();



                    speech.Speak(textBox1.Text);
                    //speech.SpeakAsync(textBox1.Text);  //异步朗读文本

                    speech.Volume = 80;     //设置音量

                    speech.Rate = 2;    //设置朗读速度

                    //输出文件

                    //speech.SetOutputToWaveFile();//输出语言文件
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); return; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
