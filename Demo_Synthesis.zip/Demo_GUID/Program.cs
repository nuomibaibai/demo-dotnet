﻿using System;

namespace Demo_GUID
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Guid.NewGuid());
            Console.WriteLine(Guid.NewGuid().ToString("N"));
            Console.WriteLine(Guid.NewGuid().ToString("D"));
            Console.WriteLine(Guid.NewGuid().ToString("B"));
            Console.WriteLine(Guid.NewGuid().ToString("P"));
            Console.WriteLine(Guid.NewGuid().ToString("X"));
        }
    }
}
