﻿using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Layout.Pattern;
using log4net.Repository.Hierarchy;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace Demo_log4net
{
    public class LogManager
    {

        public log4net.ILog Logger = null;

        public LogManager(string connection)
        {
            Init();//加载配置文件
            ConfigConnection(connection, "Logger");//修改连接字符串
            Logger = GetLogger("Logger");
        }

        /// <summary>
        /// 设置DB连接字符串
        /// </summary>
        /// <param name="conString">连接字符串</param>
        /// <param name="loggerName">loggerName</param>
        /// <param name="appenderName">appenderName</param>
        public static void ConfigConnection(string conString, string loggerName, string appenderName = "AdoNetAppender_SQLServer")
        {
            try
            {
                Hierarchy h = log4net.LogManager.GetRepository() as Hierarchy;
                if (h != null)
                {
                    AdoNetAppender adoAppender = (AdoNetAppender)h.GetLogger(loggerName,
                        h.LoggerFactory).GetAppender(appenderName);
                    if (adoAppender != null)
                    {
                        adoAppender.ConnectionString = conString;
                        adoAppender.ActivateOptions();
                    }
                }

            }
            catch (NullReferenceException) { }
        }


        /// <summary>
        /// 初始化HY.Log,  Log配置文件需要写到 Web.config  OR  App.config
        /// </summary>
        public static void Init()
        {
            XmlConfigurator.Configure();
        }

        /// <summary>
        /// 初始化HY.Log, 
        /// </summary>
        /// <param name="configFileName">制定Log配置文件的文件绝对路径</param>
        public static void Init(string configFileName)
        {
            XmlConfigurator.Configure(new FileInfo(configFileName));
        }



        /// <summary>
        /// 检索Logger名称返回日志处理接口
        /// </summary>
        /// <param name="name">Logger名称</param>
        /// <returns>日志接口</returns>
        public static ILog GetLogger(string name)
        {
            var log4Logger = log4net.LogManager.GetLogger(name);
            return log4Logger;
        }

    }


    public class CMLogLayout : log4net.Layout.PatternLayout
    {
        public CMLogLayout()
        {

            this.AddConverter("CMLog", typeof(CustomerPatternConverter));

        }
    }

    public class CustomerPatternConverter : PatternLayoutConverter
    {
        protected override void Convert(System.IO.TextWriter writer, log4net.Core.LoggingEvent loggingEvent)
        {
            if (Option != null)
            {
                // Write the value for the specified key
                WriteObject(writer, loggingEvent.Repository, LookupProperty(Option, loggingEvent));
            }
            else
            {
                // Write all the key value pairs
                WriteDictionary(writer, loggingEvent.Repository, loggingEvent.GetProperties());
            }
        }

        /// <summary>
        /// 通过反射获取传入的日志对象的某个属性的值
        /// </summary>
        /// <param name="property"></param>
        /// <returns></returns>
        private object LookupProperty(string property, log4net.Core.LoggingEvent loggingEvent)
        {
            object propertyValue = string.Empty;

            PropertyInfo propertyInfo = loggingEvent.MessageObject.GetType().GetProperty(property);
            if (propertyInfo != null)
                propertyValue = propertyInfo.GetValue(loggingEvent.MessageObject, null);

            return propertyValue;
        }
    }

    public class CMLogModel
    {
        //@CL_User,@LogDateTime, @ActionName, @ActionUrl, @OPStatus, @LogType, @LogMessage
        public string CLUser { get; set; }

        public string LogDateTime { get; set; }


        public string ActionName { get; set; }

        public string ActionUrl { get; set; }

        public string OPStatus { get; set; }

        public string LogType { get; set; }

        public string LogMessage { get; set; }

    }
}
