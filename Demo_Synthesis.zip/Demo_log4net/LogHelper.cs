﻿using log4net.Core;
using log4net.Layout;
using log4net.Layout.Pattern;
using System;

namespace Demo_log4net
{
    public class LogHelper
    {
            private static readonly log4net.ILog logsql = log4net.LogManager.GetLogger("LogSQL");   //选择<logger name="logsql">的配置 

            /// <summary>
            /// 添加数据库日志记录
            /// </summary>
            /// <param name="category">日志类别</param>
            /// <param name="message">日志内容</param>
            public static void AddLogToDb(string category, string message)
            {

                logsql.Info(message);
            }

            /// <summary>
            /// 添加数据库日志记录
            /// </summary>
            /// <param name="category">日志类别</param>
            /// <param name="message">日志内容</param>
            /// <param name="Exception">错误内容</param>
            public static void AddLogToDb(string category, string message, Exception ex)
            {
                logsql.Error(message, ex);
            }
        }

        /// <summary>
        /// 自定义的消息实体 
        /// </summary>
        public class MessageLog
        {
            /// <summary>
            /// 日志类别
            /// </summary>
            public string Category { get; set; }

            /// <summary>
            /// 日志消息
            /// </summary>
            public string Message { get; set; }
        }

        /// <summary>
        /// 自定义转化器 需要自定义字段被log4net识别都需要自定义转化器
        /// </summary>
        internal sealed class CategoryPatternConverter : PatternLayoutConverter
        {
            protected override void Convert(System.IO.TextWriter writer, LoggingEvent loggingEvent)
            {
                var messageLog = loggingEvent.MessageObject as MessageLog;
                if (messageLog != null)
                {
                    writer.Write(messageLog.Category);
                }
            }
        }

        /// <summary>
        /// 自定义转化器 需要自定义字段被log4net识别都需要自定义转化器
        /// </summary>
        internal sealed class MessagePatternConverter : PatternLayoutConverter
        {
            protected override void Convert(System.IO.TextWriter writer, LoggingEvent loggingEvent)
            {
                var messageLog = loggingEvent.MessageObject as MessageLog;
                if (messageLog != null)
                {
                    writer.Write(messageLog.Message);
                }
            }
        }

        /// <summary>
        /// 消息转换器 在配置文件中需要使用
        /// </summary>
        public class MessageLayout : PatternLayout
        {
            public MessageLayout()
            {
                this.AddConverter("Category", typeof(CategoryPatternConverter));
                this.AddConverter("Message", typeof(MessagePatternConverter));
            }
        }
    }