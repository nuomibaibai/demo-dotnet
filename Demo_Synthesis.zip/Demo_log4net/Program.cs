﻿using System;

namespace Demo_log4net
{
    class Program
    {
        static void Main(string[] args)
        {
            LogManager logManager = new LogManager("Data Source=127.0.0.1;Initial Catalog=Log4gnet; User Id=sa; Password=123456;");
            logManager.Logger.Info(new CMLogModel { CLUser = "CLUser01", LogDateTime = DateTime.Now.ToString("yyy-MM-dd HH:mm:sss"), ActionName = "ActionName01", ActionUrl = "ActionUrl01", LogType = "Info", OPStatus = "成功", LogMessage = "LogMessage01" });
            Console.WriteLine("02成功!");
        }
    }
}
