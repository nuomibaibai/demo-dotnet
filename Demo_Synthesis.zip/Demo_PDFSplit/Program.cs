﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using Common;
using PdfiumViewer;

namespace Demo_PDFSplit
{
    class Program
    {
        static void Main(string[] args)
        {
            string TargetPath = $@"E:\Desktop\testpdf\Target\{DateTime.Now:yyyyMMddHHmmssfff}";
            //Pdf文件
            string PDFPath = @"E:\Desktop\testpdf\PDF\Yodobashi Camera 20210531 cut-off_看图王.pdf";
            string PDFOnlyName = Path.GetFileNameWithoutExtension(PDFPath);
            string PDFExtension = Path.GetExtension(PDFPath);
            string PDFName = $"{PDFOnlyName}_{PDFExtension}";

            if (File.Exists(PDFPath))//必须判断要复制的文件是否存在
            {
                TargetPath += $@"\{PDFOnlyName}";
                FileHelper.CreateFolder(TargetPath);
                var pdf = PdfDocument.Load(PDFPath);
                var pdfpage = pdf.PageCount;
                var pagesizes = pdf.PageSizes;
                for (int i = 1; i <= pdfpage; i++)
                {
                    Size size = new Size
                    {
                        Height = (int)pagesizes[(i - 1)].Height,
                        Width = (int)pagesizes[(i - 1)].Width
                    };
                    //可以把".jpg"写成其他形式

                    string ImgNameFileName = $@"{ PDFName }-{ i}";
                    string ImgNameExtension = ".jpg";
                    string imgTargetPath = Path.Combine(TargetPath, $"{ImgNameFileName}{ImgNameExtension}");
                    RenderPage(PDFPath, i, size, imgTargetPath,400);
                }
                Console.WriteLine("已完成");
            }
        }


        #region pdf文件处理
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pdfPath">pdf路径</param>
        /// <param name="pageNumber">页码</param>
        /// <param name="size">pdf文件尺寸</param>
        /// <param name="outputPath">源文件路径</param>
        /// <param name="dpi">图片宽高</param>
        public static void RenderPage(string pdfPath, int pageNumber, Size size, string outputPath, int dpi = 300)
        {
            using (var document = PdfDocument.Load(pdfPath))
            {
                using (var stream = new FileStream(outputPath, FileMode.Create))
                {
                    using (var image = GetPageImage(pageNumber, size, document, dpi))
                    {
                        image.Save(stream, ImageFormat.Jpeg);
                    }
                }
            }
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageNumber">pdf文件张数</param>
        /// <param name="size">pdf文件尺寸</param>
        /// <param name="document">pdf文件位置</param>
        /// <param name="dpi">图片宽高</param>
        /// <returns></returns>
        private static Image GetPageImage(int pageNumber, Size size, PdfDocument document, int dpi)
        {
            return document.Render(pageNumber - 1, size.Width, size.Height, dpi, dpi, PdfRenderFlags.Annotations);
        }
        #endregion
    }
}
