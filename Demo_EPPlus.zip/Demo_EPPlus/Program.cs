﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace Demo_EPPlus
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var datatable = GetDataTableByFilePath(@"F:\HudsonHU\Gitee项目\历峰\sales-cut-off\上传文件压缩包\GK Clients 20220511.xlsx");
                Console.WriteLine("ok");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"error,{ex.Message}");
            }
        }

        /// <summary>
        /// 根据文件路径获取datatable
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <returns></returns>
        private static DataTable GetDataTableByFilePath(string filePath)
        {
            //最终的datatable
            var resultData = new DataTable();

            try
            {
                using (var stream = new FileStream(filePath, FileMode.Open))
                {
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (ExcelPackage package = new ExcelPackage(stream))
                    {
                        ExcelWorksheet sheet = package.Workbook.Worksheets[0];

                        //dt = sheet.Cells.ToDataTable();

                        var fileName = Path.GetFileName(filePath).ToLower();
                        int beginRowIndex = 0;
                        int columnCount = sheet.Dimension.End.Column;
                        int rowCount = sheet.Dimension.End.Row;

                        var data = (object[,])sheet.Cells.Value;

                        //时间类型的列
                        List<string> datetimeColumnNameList = new()
                        {
                            "TimeCalendarDay",
                            "RefTransactionDate",
                            "TimeIssueDate",
                            "TimeValidFrom",
                            "TimeRedemptionDate",
                            "DocumentDate",
                            "PostingDate",
                        };

                        if (fileName.Contains("bi") || fileName.Contains("sales") || fileName.Contains("gk"))
                        {
                            beginRowIndex = 3;
                            //去掉最后一行数据
                            rowCount--;

                            //对应需要新增的列
                            Dictionary<string, string> addColumnNameDic = new()
                            {
                                { "Site", "SiteName" },
                                { "SiteIssuance", "SiteName" },
                                { "Articletype", "ArticleTypeName" },
                                { "Article", "ArticleName" },
                                { "HierLvl6", "HierLvl7" },
                                { "Customer", "CustomerName" },
                                { "SiteRedemption", "SiteRedemptionName" },
                            };

                            for (int i = 0; i < columnCount; i++)
                            {
                                var colname1 = ClassHelper.ReplaceExcelStr((data[beginRowIndex - 1, i] ?? "").ToString());
                                var colname2 = ClassHelper.ReplaceExcelStr((data[beginRowIndex, i] ?? "").ToString());
                                if (string.IsNullOrEmpty(colname1))
                                {
                                    if (!string.IsNullOrEmpty(colname2))
                                    {
                                        resultData.Columns.Add(colname2);

                                        if (addColumnNameDic.ContainsKey(colname2))
                                        {
                                            resultData.Columns.Add(addColumnNameDic[colname2]);
                                        }
                                    }
                                }
                                else
                                {
                                    resultData.Columns.Add(colname1);
                                }
                            }
                        }
                        else
                        {
                            //去掉最后一行数据
                            rowCount--;
                            for (int i = 0; i < columnCount; i++)
                            {
                                var colname = ClassHelper.ReplaceExcelStr((data[beginRowIndex, i] ?? "").ToString());
                                if (!string.IsNullOrEmpty(colname))
                                {
                                    resultData.Columns.Add(colname);
                                }
                            }
                        }

                        for (int i = beginRowIndex + 1; i < rowCount; i++)
                        {
                            DataRow dataRow = resultData.NewRow();
                            for (int j = 0; j < resultData.Columns.Count; j++)
                            {
                                var value = data[i, j];

                                if (datetimeColumnNameList.Contains(resultData.Columns[j].ColumnName))
                                {
                                    try
                                    {
                                        if (!DateTime.TryParse(value.ToString(), out DateTime dateTime))
                                        {
                                            value = DateTime.FromOADate(double.Parse(value.ToString())).ToString("yyyy/MM/dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                                        }
                                        else
                                        {
                                            value = dateTime;
                                        }
                                    }
                                    catch (Exception)
                                    {
                                        value = null;
                                    }
                                }

                                dataRow[j] = value;
                            }
                            resultData.Rows.Add(dataRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //_logger.LogError(ex, ex.Message);
                throw new Exception(ex.Message);
            }

            return resultData;
        }
    }

    public class ClassHelper
    {
        public static string ReplaceExcelStr(string value)
        {
            return value.Replace("-", "").Replace(".", "").Replace("\n", "").Replace("%", "Percent").Split('(')[0].Replace(" ", "");
        }
    }
}
