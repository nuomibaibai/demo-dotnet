﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Azure;
using Azure.Core;
using Azure.Identity;
using Azure.Storage;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;

namespace Demo_DataLake
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private async void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Stopwatch stw = new Stopwatch();
                stw.Start();
                string filename = this.txtFileName.Text;
                if (filename.Length == 0)
                {
                    this.listBox1.Items.Add($"上传失败，请选择文件");
                    return;
                }
                if (!File.Exists(filename))
                {
                    this.listBox1.Items.Add($"上传失败，文件不存在");
                    return;
                }
                FileInfo fileInfo = new FileInfo(filename);
                long fileSize = fileInfo.Length;

                DateTime dateTimeStart = DateTime.Now;
                this.listBox1.Items.Add($"开始上传，{dateTimeStart.ToString("yyyy-MM-dd HH:mm:ss")}");
                DataLakeServiceClient dataLakeServiceClient = null;
                GetDataLakeServiceClient(ref dataLakeServiceClient, "kguser", "ar3kZNfq/6xvgbCeb2ScnRLHtZdEesKnEqERmWAKiGT7qE+pIsaaXWov0h62+w2/fMk1WKe6iL+AKixZxvV/ZA==");
                await UploadFile(dataLakeServiceClient.GetFileSystemClient("rongqi1"), filename);
                DateTime dateTimeEnd = DateTime.Now;
                this.listBox1.Items.Add($"上传结束，{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                this.listBox1.Items.Add($"文件大小，{fileSize / 1024}KB");
                stw.Stop();
                this.listBox1.Items.Add($"总耗时，{ stw.Elapsed:hh\\:mm\\:ss\\.fff}.");
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// 连接到帐户
        /// </summary>
        /// <param name="dataLakeServiceClient"></param>
        /// <param name="accountName"></param>
        /// <param name="accountKey"></param>

        public static void GetDataLakeServiceClient(ref DataLakeServiceClient dataLakeServiceClient,
    string accountName, string accountKey)
        {
            StorageSharedKeyCredential sharedKeyCredential =
                new StorageSharedKeyCredential(accountName, accountKey);

            string dfsUri = "https://" + accountName + ".dfs.core.chinacloudapi.cn";

            dataLakeServiceClient = new DataLakeServiceClient
                (new Uri(dfsUri), sharedKeyCredential);
        }
        /// <summary>
        /// 使用 Azure Active Directory (Azure AD) 进行连接
        /// </summary>
        /// <param name="dataLakeServiceClient"></param>
        /// <param name="accountName"></param>
        /// <param name="clientID"></param>
        /// <param name="clientSecret"></param>
        /// <param name="tenantID"></param>
        public static void GetDataLakeServiceClient(ref DataLakeServiceClient dataLakeServiceClient,
    String accountName, String clientID, string clientSecret, string tenantID)
        {

            TokenCredential credential = new ClientSecretCredential(
                tenantID, clientID, clientSecret, new TokenCredentialOptions());

            string dfsUri = "https://" + accountName + ".dfs.core.chinacloudapi.cn";

            dataLakeServiceClient = new DataLakeServiceClient(new Uri(dfsUri), credential);
        }
        /// <summary>
        /// 创建容器
        /// </summary>
        /// <param name="serviceClient"></param>
        /// <returns></returns>
        public async Task<DataLakeFileSystemClient> CreateFileSystem
    (DataLakeServiceClient serviceClient)
        {
            return await serviceClient.CreateFileSystemAsync("my-file-system");
        }
        /// <summary>
        /// 创建目录
        /// </summary>
        /// <param name="serviceClient"></param>
        /// <param name="fileSystemName"></param>
        /// <returns></returns>
        public async Task<DataLakeDirectoryClient> CreateDirectory
    (DataLakeServiceClient serviceClient, string fileSystemName)
        {
            DataLakeFileSystemClient fileSystemClient =
                serviceClient.GetFileSystemClient(fileSystemName);

            DataLakeDirectoryClient directoryClient =
                await fileSystemClient.CreateDirectoryAsync("my-directory");

            return await directoryClient.CreateSubDirectoryAsync("my-subdirectory");
        }

        /// <summary>
        /// 重命名目录
        /// </summary>
        /// <param name="fileSystemClient"></param>
        /// <returns></returns>
        public async Task<DataLakeDirectoryClient>
    RenameDirectory(DataLakeFileSystemClient fileSystemClient)
        {
            DataLakeDirectoryClient directoryClient =
                fileSystemClient.GetDirectoryClient("my-directory/my-subdirectory");

            return await directoryClient.RenameAsync("my-directory/my-subdirectory-renamed");
        }

        /// <summary>
        /// 移动目录
        /// </summary>
        /// <param name="fileSystemClient"></param>
        /// <returns></returns>
        public async Task<DataLakeDirectoryClient> MoveDirectory
    (DataLakeFileSystemClient fileSystemClient)
        {
            DataLakeDirectoryClient directoryClient =
                 fileSystemClient.GetDirectoryClient("my-directory/my-subdirectory-renamed");

            return await directoryClient.RenameAsync("my-directory-2/my-subdirectory-renamed");
        }

        /// <summary>
        /// 删除目录
        /// </summary>
        /// <param name="fileSystemClient"></param>
        public void DeleteDirectory(DataLakeFileSystemClient fileSystemClient)
        {
            DataLakeDirectoryClient directoryClient =
                fileSystemClient.GetDirectoryClient("my-directory");

            directoryClient.Delete();
        }

        /// <summary>
        /// 将文件上传到目录
        /// </summary>
        /// <param name="fileSystemClient"></param>
        /// <returns></returns>
        public async Task UploadFile(DataLakeFileSystemClient fileSystemClient,string filename = @"E:\Desktop\test.txt")
        {
            DataLakeDirectoryClient directoryClient =
                fileSystemClient.GetDirectoryClient("my-directory");

            DataLakeFileClient fileClient = await directoryClient.CreateFileAsync(Path.GetFileName(filename));

            FileStream fileStream =
                File.OpenRead(filename);

            long fileSize = fileStream.Length;

            await fileClient.AppendAsync(fileStream, offset: 0);

            await fileClient.FlushAsync(position: fileSize);

        }

        /// <summary>
        /// 将大型文件上传到目录
        /// </summary>
        /// <param name="fileSystemClient"></param>
        /// <returns></returns>
        public async Task UploadFileBulk(DataLakeFileSystemClient fileSystemClient,string filename = "C:\\Users\\contoso\\file-to-upload.txt")
        {
            DataLakeDirectoryClient directoryClient =
                fileSystemClient.GetDirectoryClient("my-directory");

            DataLakeFileClient fileClient = directoryClient.GetFileClient("uploaded-file.txt");

            FileStream fileStream =
                File.OpenRead(filename);

            await fileClient.UploadAsync(fileStream);

        }

        /// <summary>
        /// 从目录下载
        /// </summary>
        /// <param name="fileSystemClient"></param>
        /// <returns></returns>
        public async Task DownloadFile(DataLakeFileSystemClient fileSystemClient,string filename = "C:\\Users\\contoso\\my-image-downloaded.png")
        {
            DataLakeDirectoryClient directoryClient =
                fileSystemClient.GetDirectoryClient("my-directory");

            DataLakeFileClient fileClient =
                directoryClient.GetFileClient("my-image.png");

            Response<FileDownloadInfo> downloadResponse = await fileClient.ReadAsync();

            BinaryReader reader = new BinaryReader(downloadResponse.Value.Content);

            FileStream fileStream =
                File.OpenWrite(filename);

            int bufferSize = 4096;

            byte[] buffer = new byte[bufferSize];

            int count;

            while ((count = reader.Read(buffer, 0, buffer.Length)) != 0)
            {
                fileStream.Write(buffer, 0, count);
            }

            await fileStream.FlushAsync();

            fileStream.Close();
        }

        /// <summary>
        /// 列出目录内容
        /// </summary>
        /// <param name="fileSystemClient"></param>
        /// <returns></returns>
        public async Task ListFilesInDirectory(DataLakeFileSystemClient fileSystemClient)
        {
            IAsyncEnumerator<PathItem> enumerator =
                fileSystemClient.GetPathsAsync("my-directory").GetAsyncEnumerator();

            await enumerator.MoveNextAsync();

            PathItem item = enumerator.Current;

            while (item != null)
            {
                Console.WriteLine(item.Name);

                if (!await enumerator.MoveNextAsync())
                {
                    break;
                }

                item = enumerator.Current;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "选择文件上传";
            
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.txtFileName.Text = openFileDialog.FileName;
            }
        }
    }
}
