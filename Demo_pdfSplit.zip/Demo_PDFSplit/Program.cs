﻿using O2S.Components.PDFRender4NET;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Demo_PDFSplit
{
    class Program
    {
        static void Main(string[] args)
        {
            #region PDF分割
            SplitPDF();
            #endregion

            #region 缩放图片
            //string filename = @"E:\Desktop\testinvoice\测试代开\2021年10月代开-1.jpg";
            //Bitmap pageImage = new Bitmap(filename);

            //string filepath = $@"E:\Desktop\testinvoice\测试代开\2021年10月代开-1_x5.jpg";

            //FileInfo fileInfo = new FileInfo(filename);
            //Console.WriteLine(Convert.ToDecimal(fileInfo.Length) / 1024);

            //Magnifier(pageImage,5, filepath);
            //Console.WriteLine("已完成");
            #endregion
        }

        private static void SplitPDF()
        {
            string TargetPath = $@"E:\Desktop\testpdf\Target\IT\{DateTime.Now:yyyyMMddHHmmssfff}";
            //Pdf文件
            string PDFPath = @"E:\Desktop\戴珂\OCR二期\Iyotetsu Takashimaya 211215.pdf";
            string PDFOnlyName = Path.GetFileNameWithoutExtension(PDFPath);
            string PDFName = $"{PDFOnlyName}";

            if (File.Exists(PDFPath))//必须判断要复制的文件是否存在
            {
                TargetPath += $@"\{PDFOnlyName}";

                try
                {
                    if (!Directory.Exists(TargetPath))//如果不存在就创建file文件夹
                        Directory.CreateDirectory(TargetPath);
                }
                catch
                { }
                PDFTranImgHelp.ConvertPDF2Image(PDFPath, TargetPath, PDFName, 0, 50, ImageFormat.Png, Definition.Three);

                Console.WriteLine("已完成");
            }
        }

        public static void Magnifier(Bitmap srcbitmap, int multiple, string filepath)
        {
            if (multiple <= 0) { multiple = 1; }
            Bitmap bitmap = new Bitmap(srcbitmap.Size.Width * multiple, srcbitmap.Size.Height * multiple);
            BitmapData srcbitmapdata = srcbitmap.LockBits(new Rectangle(new System.Drawing.Point(0, 0), srcbitmap.Size), ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            BitmapData bitmapdata = bitmap.LockBits(new Rectangle(new System.Drawing.Point(0, 0), bitmap.Size), ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            unsafe
            {
                byte* srcbyte = (byte*)(srcbitmapdata.Scan0.ToPointer());
                byte* sourcebyte = (byte*)(bitmapdata.Scan0.ToPointer());
                for (int y = 0; y < bitmapdata.Height; y++)
                {
                    for (int x = 0; x < bitmapdata.Width; x++)
                    {
                        long index = (x / multiple) * 4 + (y / multiple) * srcbitmapdata.Stride;
                        sourcebyte[0] = srcbyte[index];
                        sourcebyte[1] = srcbyte[index + 1];
                        sourcebyte[2] = srcbyte[index + 2];
                        sourcebyte[3] = srcbyte[index + 3];
                        sourcebyte += 4;
                    }
                }
            }
            srcbitmap.UnlockBits(srcbitmapdata);
            bitmap.UnlockBits(bitmapdata);
            bitmap.Save(filepath);
        }


        //times需要放大或者缩小的倍数
        public static void imresize(Bitmap Image, double times,string filepath)
        {
            int width = Image.Width;
            int height = Image.Height;
            int IOwidth = (int)Math.Round(width * times);
            int IOheight = (int)Math.Round(height * times);
            Bitmap IOimage = new Bitmap(IOwidth, IOheight, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            for (int y1 = 0; y1 < IOheight; y1++)
            {
                for (int x1 = 0; x1 < IOwidth; x1++)
                {
                    int x = (int)Math.Round(x1 * (1 / times));
                    int y = (int)Math.Round(y1 * (1 / times));
                    //反向映射坐标，不在原图內，直接取边界作为Pixel。
                    if (x > (width - 1))
                    {
                        x = width - 1;
                    }
                    if (y > (height - 1))
                    {
                        y = height - 1;
                    }
                    IOimage.SetPixel(x1, y1, Image.GetPixel(x, y));
                }
            }
            IOimage.Save(filepath);
        }


        public enum Definition
        {
            One = 1, Two = 2, Three = 3, Four = 4, Five = 5, Six = 6, Seven = 7, Eight = 8, Nine = 9, Ten = 10
        }
        public static class PDFTranImgHelp
        {
            /// <summary>
            /// 将PDF文档转换为图片的方法
            /// </summary>
            /// <param name="pdfInputPath">PDF文件路径</param>
            /// <param name="imageOutputPath">图片输出路径</param>
            /// <param name="imageName">生成图片的名字</param>
            /// <param name="startPageNum">从PDF文档的第几页开始转换</param>
            /// <param name="endPageNum">从PDF文档的第几页开始停止转换</param>
            /// <param name="imageFormat">设置所需图片格式</param>
            /// <param name="definition">设置图片的清晰度，数字越大越清晰</param>
            public static void ConvertPDF2Image(string pdfInputPath, string imageOutputPath,
                string imageName, int startPageNum, int endPageNum, ImageFormat imageFormat, Definition definition)
            {
                using (PDFFile pdfFile = PDFFile.Open(pdfInputPath))
                {
                    // validate pageNum
                    if (startPageNum <= 0)
                    {
                        startPageNum = 1;
                    }
                    if (endPageNum > pdfFile.PageCount)
                    {
                        endPageNum = pdfFile.PageCount;
                    }
                    if (startPageNum > endPageNum)
                    {
                        int tempPageNum = startPageNum;
                        startPageNum = endPageNum;
                        endPageNum = startPageNum;
                    }
                    // start to convert each page
                    for (int i = startPageNum; i <= endPageNum; i++)
                    {
                        using (Bitmap pageImage = pdfFile.GetPageImage(i - 1, 56 * (int)definition))
                        {
                            //pageImage.RotateFlip(RotateFlipType.Rotate270FlipNone);
                            string filepath = $@"{imageOutputPath}\{imageName}{i}.{imageFormat.ToString().ToLower()}";
                            pageImage.Save(filepath, imageFormat);
                        }
                    }
                }
            }
        }
    }
}
