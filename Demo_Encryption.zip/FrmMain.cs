﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Encryption
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
            Application.Exit();
        }

        private void btnEncryption_Click(object sender, EventArgs e)
        {
            string msg = "加密完成!";
            string EncryptionStr = this.txtEncryption.Text;
            if (EncryptionStr.Length == 0)
            {
                msg = "加密文本不能为空!";
                this.lblMsg.Text = msg;
                MessageBox.Show(msg);
                return;
            }

            this.txtResult.Text = Common.EncryptionHelper.DESEncrypt(EncryptionStr);
            this.lblMsg.Text = msg;
        }

        private void btnDecryption_Click(object sender, EventArgs e)
        {
            string msg = "解密完成!";
            string DecryptionStr = this.txtDecryption.Text;
            if (DecryptionStr.Length == 0)
            {
                msg = "解密文本不能为空!";
                this.lblMsg.Text = msg;
                MessageBox.Show(msg);
                return;
            }

            this.txtResult.Text = Common.DecryptionHelper.DESDecrypt(DecryptionStr);
            this.lblMsg.Text = msg;
        }
    }
}
